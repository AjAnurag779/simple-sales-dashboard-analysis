# Task 8 – Simple Sales Dashboard Design

This project completes **Task 8: Simple Sales Dashboard Design** from the Elevate Labs Data Analyst Internship.

## Objective
Create a basic interactive-style dashboard that shows sales performance by **product category**, **region**, and **month**.

## Dataset
File used: `Superstore_Sales.csv`

Columns:
- `Order Date`
- `Region`
- `Category`
- `Sales`
- `Profit`

## Steps Followed

1. **Imported the CSV file** into a data tool (can be Power BI, Tableau, or Python/Pandas).
2. **Converted** `Order Date` to `Month-Year` format for monthly trend analysis.
3. **Created 3 visuals** (saved in the `visuals/` folder):
   - `line_sales_over_months.png`: Line Chart – Sales over Months.
   - `bar_sales_by_region.png`: Bar Chart – Sales by Region.
   - `donut_sales_by_category.png`: Donut Chart – Sales by Category.
4. Highlighted top-performing regions and categories using these visuals.
5. Wrote **3–4 key insights** in `insights.txt` based on the charts.

## How to Rebuild This in Power BI or Tableau

1. Load `Superstore_Sales.csv`.
2. Create a calculated column or field for **Month-Year** from `Order Date`.
3. Build:
   - A **Line Chart** with `Month-Year` on the X-axis and sum of `Sales` on the Y-axis.
   - A **Bar Chart** with `Region` on the X-axis and sum of `Sales` on the Y-axis.
   - A **Donut/Pie Chart** with `Category` as the legend and sum of `Sales` as values.
4. Add a **slicer/filter** for `Region` or `Category` to make the dashboard interactive.
5. Export the dashboard as a **screenshot or PDF** for submission.

## Deliverables Included

- `Superstore_Sales.csv` – Sales dataset.
- `visuals/` – PNG files for all charts (you can treat these as dashboard screenshots).
- `insights.txt` – 3–4 insights from the visuals.
- `README.md` – This documentation for GitHub.

You can directly upload this folder (as a ZIP) to GitHub as your Task 8 submission.
